#Importo la clase o funcion App desde el archivo form_login.py
# que está en el paquete o directorio `forms`. Este archivo contiene
# el formulario de inicio de sesión.
from forms.form_login import App

#Instancio la clase App que representa la ventana principal del login
App()

