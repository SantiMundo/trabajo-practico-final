import tkinter as tk
from tkinter import ttk, messagebox
from tkinter.font import BOLD
import sqlite3  # Importar sqlite3 para la base de datos
import util.generic as utl
from forms.cliente import Usuario
from forms.form_master import MasterPanel


class App:
    def conectar_db(self):
        """Conectar a la base de datos SQLite."""
        conn = sqlite3.connect('clientes.db')
        return conn

    def crear_tabla(self):
        """Crear la tabla de usuarios si no existe."""
        conn = self.conectar_db()
        cursor = conn.cursor()
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            nombre TEXT PRIMARY KEY,
            genero TEXT,
            contrasena TEXT
        )
        ''')
        conn.commit()
        conn.close()

    def verificar(self):
        usu = self.usuario.get()
        password = self.password.get()

        # Verificación de administrador
        if usu == "santi23" and password == "12345678":
            self.ventana.destroy()  # Cerrar la ventana actual
            MasterPanel()  # Abrir el panel de administración

        # Verificación de cliente
        else:
            # Consultar la base de datos
            conn = self.conectar_db()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM usuarios WHERE nombre=? AND contrasena=?", (usu, password))
            resultado = cursor.fetchone()
            conn.close()

            if resultado:  # Si se encontró un usuario
                self.ventana.destroy()  # Cerrar la ventana actual
                Usuario()  # Abrir el panel de usuario
            else:
                messagebox.showerror(message="La contraseña no es correcta", title="Mensaje")

    def registrar_cliente(self, nombre, genero, contrasena):
        # Verificar si todos los campos están completos
        if not nombre or not genero or not contrasena:
            messagebox.showerror("Error", "Todos los campos deben ser completados.")
            return

        # Guardar los datos en la base de datos
        try:
            conn = self.conectar_db()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO usuarios (nombre, genero, contrasena) VALUES (?, ?, ?)",
                           (nombre, genero, contrasena))
            conn.commit()
            conn.close()
            messagebox.showinfo("Registro exitoso", "El cliente ha sido registrado exitosamente.")
        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "El nombre de usuario ya está registrado.")

    def abrir_ventana_registro(self):
        # Crear la ventana de registro
        ventana_registro = tk.Toplevel()
        ventana_registro.title("Registro de Cliente")

        # Crear etiquetas y campos de entrada
        tk.Label(ventana_registro, text="Nombre:").grid(row=0, column=0)
        entry_nombre = tk.Entry(ventana_registro)
        entry_nombre.grid(row=0, column=1)

        tk.Label(ventana_registro, text="Género:").grid(row=1, column=0)
        genero_var = tk.StringVar(value="masculino")  # Valor predeterminado
        tk.Radiobutton(ventana_registro, text="Masculino", variable=genero_var, value="masculino").grid(row=1, column=1)
        tk.Radiobutton(ventana_registro, text="Femenino", variable=genero_var, value="femenino").grid(row=1, column=2)

        tk.Label(ventana_registro, text="Contraseña:").grid(row=2, column=0)
        entry_contrasena = tk.Entry(ventana_registro, show="*")
        entry_contrasena.grid(row=2, column=1)

        # Botón para registrar
        tk.Button(ventana_registro, text="Registrarse",
                  command=lambda: self.registrar_cliente(entry_nombre.get(), genero_var.get(),
                                                         entry_contrasena.get())).grid(row=3, columnspan=3)

    def __init__(self):
        self.ventana = tk.Tk()
        self.ventana.title('Inicio de sesión')
        self.ventana.geometry('800x500')
        self.ventana.config(bg='#fcfcfc')
        self.ventana.resizable(width=0, height=0)
        utl.centrar_ventana(self.ventana, 800, 500)

        self.crear_tabla()  # Crear tabla de usuarios si no existe

        logo = utl.leer_imagen(".\imagenes\logo.jpg", (600, 600))
        # Logo del marco
        frame_logo = tk.Frame(self.ventana, bd=0, width=300, relief=tk.SOLID, padx=10, pady=10, bg='#3a7ff6')
        frame_logo.pack(side="left", expand=tk.YES, fill=tk.BOTH)
        label = tk.Label(frame_logo, image=logo, bg='#3a7ff6')
        label.place(x=0, y=0, relwidth=1, relheight=1)

        # Marco de formulario
        frame_form = tk.Frame(self.ventana, bd=0, relief=tk.SOLID, bg='#fcfcfc')
        frame_form.pack(side="right", expand=tk.YES, fill=tk.BOTH)

        # Forma del marco superior
        frame_form_top = tk.Frame(frame_form, height=50, bd=0, relief=tk.SOLID, bg='black')
        frame_form_top.pack(side="top", fill=tk.X)
        title = tk.Label(frame_form_top, text="Inicio de sesión", font=('Times', 30), fg="#666a88", bg='#fcfcfc',
                         pady=50)
        title.pack(expand=tk.YES, fill=tk.BOTH)

        # Frame para llenar el formulario
        frame_form_fill = tk.Frame(frame_form, height=50, bd=0, relief=tk.SOLID, bg='#fcfcfc')
        frame_form_fill.pack(side="bottom", expand=tk.YES, fill=tk.BOTH)

        etiqueta_usuario = tk.Label(frame_form_fill, text="Usuario", font=('Times', 14), fg="#666a88", bg='#fcfcfc',
                                    anchor="w")
        etiqueta_usuario.pack(fill=tk.X, padx=20, pady=5)
        self.usuario = ttk.Entry(frame_form_fill, font=('Times', 14))
        self.usuario.pack(fill=tk.X, padx=20, pady=10)

        etiqueta_password = tk.Label(frame_form_fill, text="Contraseña", font=('Times', 14), fg="#666a88", bg='#fcfcfc',
                                     anchor="w")
        etiqueta_password.pack(fill=tk.X, padx=20, pady=5)
        self.password = ttk.Entry(frame_form_fill, font=('Times', 14))
        self.password.pack(fill=tk.X, padx=20, pady=10)
        self.password.config(show="*")

        inicio = tk.Button(frame_form_fill, text="Iniciar sesión", font=('Times', 15, BOLD), bg='#3a7ff6', bd=0,
                           fg="#fff", command=self.verificar)
        inicio.pack(fill=tk.X, padx=20, pady=20)
        inicio.bind("<Return>", (lambda event: self.verificar()))

        # Botón de registro
        registro = tk.Button(frame_form_fill, text="Registrarse", font=('Times', 15, BOLD), bg='#3a7ff6', bd=0,
                             fg="#fff", command=self.abrir_ventana_registro)
        registro.pack(fill=tk.X, padx=20, pady=10)

        self.ventana.mainloop()
