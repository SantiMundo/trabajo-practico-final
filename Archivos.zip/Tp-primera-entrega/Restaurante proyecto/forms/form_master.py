import tkinter as tk
from tkinter import ttk, messagebox
from tkinter.font import BOLD
import sqlite3

#Establecemos conexión con la base de datos 'reservas_restaurante.db'.
# Si el archivo no existe , se crea automáticamente con sus respectivos datos(mesas y reservas).


def conectar_db():
    conn = sqlite3.connect('reservas_restaurante.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS mesas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT NOT NULL,
            capacidad INTEGER NOT NULL,
            ubicacion TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS reservas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mesa_id INTEGER NOT NULL,
            cliente TEXT NOT NULL,
            fecha_reserva TEXT NOT NULL,
            FOREIGN KEY (mesa_id) REFERENCES mesas(id)
        )
    ''')
    conn.commit()
    return conn

# Clase que maneja la conexión a la base de datos y crea un cursor para ejecutar consultas SQL.
class MasterPanel:
    def __init__(self):
        self.conn = conectar_db() # Conectar a la base de datos
        self.cursor = self.conn.cursor() # Crear un cursor para consultas SQL

        # Configuración de la ventana principal
        self.ventana = tk.Tk() #Creo la ventana principal utilizando tkinter
        self.ventana.title('Panel de Administración de Mesas')
        self.ventana.geometry('1200x700') #Dimensiones de la ventana
        self.ventana.config(bg='#f0f0f0')  # Color de fondo más suave
        self.ventana.resizable(False, False) ## Desactivar el redimensionamiento de la ventana

        # Título
        titulo = tk.Label(self.ventana, text="Gestión de Mesas", font=("Arial", 24, BOLD), fg="#3a7ff6", bg='#f0f0f0')
        titulo.pack(pady=20)

        # Crear los paneles de botones y lista de mesas
        self.crear_panel_botones()
        self.crear_lista_mesas()
        self.cargar_mesas()

        self.ventana.mainloop()

    def crear_panel_botones(self):
        # Panel de botones a la izquierda
        self.frame_botones = tk.Frame(self.ventana, bg='#3a7ff6', padx=20, pady=20)# # Crear un contenedor (Frame) para los botones, con color de fondo azul y márgenes internos
        self.frame_botones.place(x=50, y=100, width=250, height=400) ## Posicionar el frame en la ventana, con una ubicación y tamaño específicos

        botones = [("Agregar Mesa", self.abrir_ventana_anadir),
                   ("Borrar Mesa", self.borrar_mesa),
                   ("Modificar Mesa", self.abrir_ventana_modificar),
                   ("Ver Reservas", self.ver_reservas)]

        # Iterar sobre la lista de botones, creando cada botón con su texto y comando asociado
        for texto, comando in botones:
            # Crea un botón en el panel de botones con el texto y la acción especificados
            btn = tk.Button(self.frame_botones, text=texto, command=comando, font=('Arial', 12, BOLD),
                            bg='#fcfcfc', fg='#3a7ff6', width=18, height=2, relief='raised')
            btn.pack(pady=10) ## Añadir un margen vertical entre los botones

    def crear_lista_mesas(self):
        #  Crea un panel a la derecha de la ventana principal para mostrar la lista de mesas.
        #     El panel tiene un color de fondo claro y márgenes internos (padding).
        self.frame_lista_mesas = tk.Frame(self.ventana, bg='#f0f0f0', padx=10, pady=10)
        self.frame_lista_mesas.place(x=350, y=100, width=800, height=500)

        # Tabla con estilo
        # Crear un estilo personalizado para los widgets de Tkinter
        estilo = ttk.Style()
        # Cambiar el tema del estilo a 'clam', que ofrece un diseño más moderno
        estilo.theme_use('clam')  # Cambia el estilo a algo más moderno
        # Configurar las propiedades del estilo para el Treeview
        estilo.configure('Treeview', background='#D3D3D3', foreground='black', rowheight=25, fieldbackground='#D3D3D3')
        estilo.map('Treeview', background=[('selected', '#3a7ff6')])

        self.lista_mesas = ttk.Treeview(self.frame_lista_mesas, columns=('ID', 'Número', 'Capacidad', 'Ubicación'),
                                        show='headings', height=20)
        # Configurar los encabezados de las columnas del Treeview
        self.lista_mesas.heading('ID', text='ID')
        self.lista_mesas.heading('Número', text='Número de Mesa')
        self.lista_mesas.heading('Capacidad', text='Capacidad')
        self.lista_mesas.heading('Ubicación', text='Ubicación')
        #Añadir el Treeview al panel, llenando el espacio disponible
        self.lista_mesas.pack(fill=tk.BOTH, expand=True)

        # Crear una barra de desplazamiento vertical para el Treeview de la lista de mesas
        scrollbar = ttk.Scrollbar(self.frame_lista_mesas, orient="vertical", command=self.lista_mesas.yview)
        # Configurar el Treeview para que utilice la barra de desplazamiento
        self.lista_mesas.configure(yscroll=scrollbar.set)
        # Colocar la barra de desplazamiento a la derecha del panel de lista de mesas y que llene el espacio vertical
        scrollbar.pack(side='right', fill='y')

    def cargar_mesas(self):
      #Elimina todas las filas actuales en el widget `lista_mesas`.
        for row in self.lista_mesas.get_children():
            self.lista_mesas.delete(row)
        # Ejecutar consulta para obtener todas las mesas de la base de datos
        self.cursor.execute("SELECT * FROM mesas")
        # Insertar las mesas obtenidas de la consulta en el widget lista_mesas
        for mesa in self.cursor.fetchall():
            self.lista_mesas.insert('', 'end', values=mesa)

    def abrir_ventana_anadir(self):
        #abre una ventana secundaria
        ventana_anadir = tk.Toplevel(self.ventana)
        ventana_anadir.title("Añadir Mesa") #titulo de la ventana
        ventana_anadir.geometry('400x200') #geometria de la ventana
        ventana_anadir.config(bg='#f0f0f0') #color del fondo

        # Etiquetas y entradas
        tk.Label(ventana_anadir, text="Número de mesa:", font=("Arial", 12), bg='#f0f0f0').grid(row=0, column=0, padx=20, pady=10)
        numero_mesa = tk.Entry(ventana_anadir, font=("Arial", 12))
        numero_mesa.grid(row=0, column=1)

        tk.Label(ventana_anadir, text="Capacidad:", font=("Arial", 12), bg='#f0f0f0').grid(row=1, column=0, padx=20, pady=10)
        capacidad_mesa = tk.Entry(ventana_anadir, font=("Arial", 12))
        capacidad_mesa.grid(row=1, column=1)

        tk.Label(ventana_anadir, text="Ubicación:", font=("Arial", 12), bg='#f0f0f0').grid(row=2, column=0, padx=20, pady=10)
        ubicacion_mesa = tk.Entry(ventana_anadir, font=("Arial", 12))
        ubicacion_mesa.grid(row=2, column=1)

        # Botón para añadir
        tk.Button(ventana_anadir, text="Añadir Mesa", font=("Arial", 12, BOLD), bg='#3a7ff6', fg='#fcfcfc',
                  command=lambda: self.agregar_mesa(numero_mesa.get(), capacidad_mesa.get(), ubicacion_mesa.get(), ventana_anadir)).grid(row=3, columnspan=2, pady=20)

    def agregar_mesa(self, numero, capacidad, ubicacion, ventana):
        #Valida los datos proporcionados para el número, capacidad y ubicación de la mesa.
        if self.validar_datos(numero, capacidad, ubicacion):
            #Insertar la nueva mesa en la base de datos
            self.cursor.execute("INSERT INTO mesas (numero, capacidad, ubicacion) VALUES (?, ?, ?) ", (numero, capacidad, ubicacion))
            self.conn.commit() # Confirmar los cambios en la base de datos
            self.cargar_mesas() # Actualizar la lista de mesas en la interfaz
            ventana.destroy() # Cerrar la ventana de entrada

    def abrir_ventana_modificar(self):
        # Obtener el elemento seleccionado en la lista de mesas
        selected_item = self.lista_mesas.selection()
        if selected_item:
            # Extraer el ID de la mesa seleccionada
            mesa_id = self.lista_mesas.item(selected_item)['values'][0]
            # Crear una nueva ventana secundaria para modificar la mesa
            ventana_modificar = tk.Toplevel(self.ventana)
            ventana_modificar.title("Modificar Mesa") # Título de la ventana
            ventana_modificar.geometry('400x200') # Tamaño de la ventana
            ventana_modificar.config(bg='#f0f0f0') # Color del fondo

            # Etiquetas y entradas
            tk.Label(ventana_modificar, text="Nuevo número de mesa:", font=("Arial", 12), bg='#f0f0f0').grid(row=0, column=0, padx=20, pady=10)
            numero_mesa = tk.Entry(ventana_modificar, font=("Arial", 12))
            numero_mesa.grid(row=0, column=1)

            tk.Label(ventana_modificar, text="Nueva capacidad:", font=("Arial", 12), bg='#f0f0f0').grid(row=1, column=0, padx=20, pady=10)
            capacidad_mesa = tk.Entry(ventana_modificar, font=("Arial", 12))
            capacidad_mesa.grid(row=1, column=1)

            tk.Label(ventana_modificar, text="Nueva ubicación:", font=("Arial", 12), bg='#f0f0f0').grid(row=2, column=0, padx=20, pady=10)
            ubicacion_mesa = tk.Entry(ventana_modificar, font=("Arial", 12))
            ubicacion_mesa.grid(row=2, column=1)

            # Botón para modificar
            tk.Button(ventana_modificar, text="Modificar Mesa", font=("Arial", 12, BOLD), bg='#3a7ff6', fg='#fcfcfc',
                      command=lambda: self.modificar_mesa(mesa_id, numero_mesa.get(), capacidad_mesa.get(), ubicacion_mesa.get(), ventana_modificar)).grid(row=3, columnspan=2, pady=20)
        else:
            messagebox.showwarning("Advertencia", "Seleccione una mesa para modificar.")

    def modificar_mesa(self, mesa_id, numero, capacidad, ubicacion, ventana):
        if self.validar_datos(numero, capacidad, ubicacion):
            ## Actualizar los detalles de la mesa en la base de datos
            self.cursor.execute("UPDATE mesas SET numero = ?, capacidad = ?, ubicacion = ? WHERE id = ?", (numero, capacidad, ubicacion, mesa_id))
            self.conn.commit() # Confirmar los cambios en la base de datos
            self.cargar_mesas() # Actualizar la lista de mesas en la interfaz
            ventana.destroy() # Cerrar la ventana de entrada

    def borrar_mesa(self):
        ## Obtener el elemento seleccionado en la lista de mesas
        selected_item = self.lista_mesas.selection()
        if selected_item:
            # Extraer el ID de la mesa seleccionada
            mesa_id = self.lista_mesas.item(selected_item)['values'][0]
            # Preguntar al administrador para confirmar la eliminación
            confirmacion = messagebox.askyesno("Confirmación", "¿Está seguro de que desea borrar la mesa seleccionada?")
            if confirmacion:
                # Eliminar la mesa de la base de datos
                self.cursor.execute("DELETE FROM mesas WHERE id = ?", (mesa_id,))
                self.conn.commit() # Confirmar los cambios en la base de datos
                self.cargar_mesas() # Actualizar la lista de mesas en la interfaz
        # Muestra un cuadro de advertencia si no se ha seleccionado ninguna mesa para borrar.
        else:
            messagebox.showwarning("Advertencia", "Seleccione una mesa para borrar.")

    def ver_reservas(self):
        # Crear una nueva ventana para mostrar las reservas
        ventana_reservas = tk.Toplevel(self.ventana)
        ventana_reservas.title("Ver Reservas") # Título de la ventana
        ventana_reservas.geometry('600x400') # Tamaño de la ventana
        ventana_reservas.config(bg='#f0f0f0') # Color del fondo

        # Tabla de reservas
        lista_reservas = ttk.Treeview(ventana_reservas, columns=('ID', 'Mesa', 'Cliente', 'Fecha de Reserva'), show='headings', height=15)
        lista_reservas.heading('ID', text='ID')
        lista_reservas.heading('Mesa', text='Número de Mesa')
        lista_reservas.heading('Cliente', text='Cliente')
        lista_reservas.heading('Fecha de Reserva', text='Fecha de Reserva')
        lista_reservas.pack(fill=tk.BOTH, expand=True)

        # Obtener las reservas de la base de datos
        self.cursor.execute('''
            SELECT reservas.id, mesas.numero, reservas.cliente, reservas.fecha_reserva
            FROM reservas
            JOIN mesas ON reservas.mesa_id = mesas.id
        ''')

        # Insertar las reservas obtenidas en la tabla
        for reserva in self.cursor.fetchall():
            lista_reservas.insert('', 'end', values=reserva)

    def validar_datos(self, numero, capacidad, ubicacion):
        if not numero or not capacidad or not ubicacion:
            # # Avisa si hay campos vacíos
            messagebox.showwarning("Advertencia", "Todos los campos son obligatorios.")
            return False
        #Avisa si la capacidad no es un número
        if not capacidad.isdigit():
            messagebox.showwarning("Advertencia", "Capacidad debe ser un número.")
            return False # Los datos son inválidos
        return True # Los datos son válidos


if __name__ == "__main__":
    MasterPanel() ## Crea y muestra la ventana principal de la aplicación
