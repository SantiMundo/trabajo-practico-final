import tkinter as tk
from tkinter import ttk, messagebox
from tkinter.font import BOLD
import sqlite3
import os

#Conecta a la base de datos 'reservas_restaurante.db'.
#Si la base de datos ya existe, se elimina para recrearla.
#Se crean las tablas 'mesas' y 'reservas' si no existen.


def conectar_db():
    if os.path.exists('reservas_restaurante.db'):
        os.remove('reservas_restaurante.db')  # Eliminar base de datos existente para recrearla

    conn = sqlite3.connect('reservas_restaurante.db')
    ...

def conectar_db():
    conn = sqlite3.connect('reservas_restaurante.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS mesas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT NOT NULL,
            capacidad INTEGER NOT NULL,
            ubicacion TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS reservas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mesa_id INTEGER,
            cliente TEXT NOT NULL,
            fecha_reserva TEXT NOT NULL,
            FOREIGN KEY(mesa_id) REFERENCES mesas(id)
        )
    ''')
    conn.commit()
    return conn

#Inicializa la clase Usuario, establece la conexión a la base de datos,
#configura la ventana principal de la interfaz gráfica y establece sus propiedades.

class Usuario:
    def __init__(self):
        self.conn = conectar_db()
        self.cursor = self.conn.cursor()

        self.ventana_cliente = tk.Tk()
        self.ventana_cliente.title('Panel Cliente')
        self.ventana_cliente.geometry("800x600")
        self.ventana_cliente.config(bg='#fcfcfc')

        # Frame principal
        self.frame_principal = tk.Frame(self.ventana_cliente, bg='#ffffff', bd=10, relief=tk.GROOVE)
        self.frame_principal.pack(padx=20, pady=20, fill=tk.BOTH, expand=True)

        # Título
        titulo = tk.Label(self.frame_principal, text="Reservas de Mesas", font=('Arial', 20, BOLD), bg='#3a7ff6', fg='#ffffff')
        titulo.pack(fill=tk.X)

        self.frame_lista_mesas = tk.Frame(self.frame_principal, bg='#fcfcfc')
        self.frame_lista_mesas.pack(padx=20, pady=20, fill=tk.BOTH, expand=True)

        # Lista de mesas
        self.lista_mesas = ttk.Treeview(self.frame_lista_mesas,
                                        columns=('ID', 'Número', 'Capacidad', 'Ubicación', 'Disponibilidad'),
                                        show='headings')
        self.lista_mesas.heading('ID', text='ID')
        self.lista_mesas.heading('Número', text='Número de Mesa')
        self.lista_mesas.heading('Capacidad', text='Capacidad')
        self.lista_mesas.heading('Ubicación', text='Ubicación')
        self.lista_mesas.heading('Disponibilidad', text='Disponibilidad')

        # Estilo de la lista
        style = ttk.Style()
        style.configure("Treeview", background="#ffffff", foreground="black", rowheight=25, fieldbackground="#ffffff")
        style.map('Treeview', background=[('selected', '#3a7ff6')])

        self.lista_mesas.pack(fill=tk.BOTH, expand=True)

        self.crear_botones_cliente()
        self.cargar_mesas_disponibles()

        self.ventana_cliente.mainloop()

    def crear_botones_cliente(self):
        botones_frame = tk.Frame(self.frame_principal, bg='#fcfcfc')
        botones_frame.pack(pady=10)

        reservar_btn = tk.Button(botones_frame, text="Reservar Mesa", command=self.abrir_ventana_reservar,
                                 font=('Arial', 12, BOLD), bg='#3a7ff6', fg='#fcfcfc', width=20)
        reservar_btn.pack(pady=10)

        # Botón para refrescar la lista de mesas
        refrescar_btn = tk.Button(botones_frame, text="Refrescar Mesas", command=self.cargar_mesas_disponibles,
                                  font=('Arial', 12, BOLD), bg='#3a7ff6', fg='#fcfcfc', width=20)
        refrescar_btn.pack(pady=10)

        # Botón para agregar mesas (función del administrador)
        agregar_mesa_btn = tk.Button(botones_frame, text="Agregar Mesa", command=self.abrir_ventana_agregar_mesa,
                                     font=('Arial', 12, BOLD), bg='#3a7ff6', fg='#fcfcfc', width=20)
        agregar_mesa_btn.pack(pady=10)

    def cargar_mesas_disponibles(self):
        for row in self.lista_mesas.get_children():
            self.lista_mesas.delete(row)

        query = '''
            SELECT mesas.id, mesas.numero, mesas.capacidad, mesas.ubicacion, 
            CASE WHEN reservas.mesa_id IS NOT NULL THEN 'Reservada' ELSE 'Disponible' END AS disponibilidad
            FROM mesas
            LEFT JOIN reservas ON mesas.id = reservas.mesa_id
        '''

        self.cursor.execute(query)
        for mesa in self.cursor.fetchall():
            self.lista_mesas.insert('', 'end', values=mesa)

    def abrir_ventana_reservar(self):
        selected_item = self.lista_mesas.selection()
        if selected_item:
            mesa_id = self.lista_mesas.item(selected_item)['values'][0]
            disponibilidad = self.lista_mesas.item(selected_item)['values'][4]

            if disponibilidad == "Disponible":
                ventana_reservar = tk.Toplevel(self.ventana_cliente)
                ventana_reservar.title("Reservar Mesa")
                ventana_reservar.config(bg='#fcfcfc')

                tk.Label(ventana_reservar, text="Nombre del cliente:", bg='#fcfcfc').grid(row=0, column=0, padx=10,
                                                                                          pady=10)
                nombre_cliente = tk.Entry(ventana_reservar)
                nombre_cliente.grid(row=0, column=1, padx=10, pady=10)

                tk.Label(ventana_reservar, text="Fecha de reserva (YYYY-MM-DD):", bg='#fcfcfc').grid(row=1, column=0,
                                                                                                     padx=10, pady=10)
                fecha_reserva = tk.Entry(ventana_reservar)
                fecha_reserva.grid(row=1, column=1, padx=10, pady=10)

                tk.Label(ventana_reservar, text="Hora de reserva (HH:MM):", bg='#fcfcfc').grid(row=2, column=0, padx=10,
                                                                                               pady=10)
                hora_reserva = tk.Entry(ventana_reservar)
                hora_reserva.grid(row=2, column=1, padx=10, pady=10)

                tk.Button(ventana_reservar, text="Confirmar Reserva",
                          command=lambda: self.reservar_mesa(mesa_id, nombre_cliente.get(), fecha_reserva.get(),
                                                             hora_reserva.get(), ventana_reservar)
                          ).grid(row=3, columnspan=2, pady=10)  # Pasar ventana_reservar
            else:
                messagebox.showwarning("Advertencia", "La mesa seleccionada ya está reservada.")
        else:
            messagebox.showwarning("Advertencia", "Seleccione una mesa para reservar.")

    def reservar_mesa(self, mesa_id, cliente, fecha, hora, ventana):
        # Verificar que todos los campos estén completos
        if not mesa_id:
            messagebox.showerror("Error", "Debe seleccionar una mesa.")
            return

        if cliente and fecha and hora:
            try:
                # Construir la fecha completa a partir de fecha y hora
                fecha_completa = f"{fecha} {hora}"
                print(f"Insertando reserva: Mesa {mesa_id}, Cliente: {cliente}, Fecha: {fecha_completa}")  # Debug

                # Insertar la reserva en la base de datos
                self.cursor.execute("INSERT INTO reservas (mesa_id, cliente, fecha_reserva) VALUES (?, ?, ?)",
                                    (mesa_id, cliente, fecha_completa))
                self.conn.commit()

                # Recargar las mesas disponibles y cerrar ventana
                self.cargar_mesas_disponibles()
                ventana.destroy()

                # Mostrar mensaje de éxito
                messagebox.showinfo("Éxito", "Mesa reservada exitosamente.")
            except Exception as e:
                messagebox.showerror("Error", f"Error al reservar la mesa: {e}")
        else:
            messagebox.showerror("Error", "Todos los campos son obligatorios.")

    def abrir_ventana_agregar_mesa(self):
        ventana_agregar = tk.Toplevel(self.ventana_cliente)
        ventana_agregar.title("Agregar Mesa (Admin)")
        ventana_agregar.config(bg='#fcfcfc')

        tk.Label(ventana_agregar, text="Número de mesa:", bg='#fcfcfc').grid(row=0, column=0, padx=10, pady=10)
        numero_mesa = tk.Entry(ventana_agregar)
        numero_mesa.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(ventana_agregar, text="Capacidad:", bg='#fcfcfc').grid(row=1, column=0, padx=10, pady=10)
        capacidad_mesa = tk.Entry(ventana_agregar)
        capacidad_mesa.grid(row=1, column=1, padx=10, pady=10)

        tk.Label(ventana_agregar, text="Ubicación:", bg='#fcfcfc').grid(row=2, column=0, padx=10, pady=10)
        ubicacion_mesa = tk.Entry(ventana_agregar)
        ubicacion_mesa.grid(row=2, column=1, padx=10, pady=10)

        tk.Button(ventana_agregar, text="Agregar Mesa",
                  command=lambda: self.agregar_mesa(numero_mesa.get(), capacidad_mesa.get(), ubicacion_mesa.get(),
                                                        ventana_agregar)).grid(row=3, columnspan=2, pady=10)

    def agregar_mesa(self, numero, capacidad, ubicacion, ventana):
        if numero and capacidad and ubicacion:
            try:
                self.cursor.execute("INSERT INTO mesas (numero, capacidad, ubicacion) VALUES (?, ?, ?)",
                                    (numero, capacidad, ubicacion))
                self.conn.commit()  # Confirmar los cambios en la base de datos
                self.cargar_mesas_disponibles()  # Recargar las mesas disponibles para el cliente
                ventana.destroy()  # Cerrar la ventana de agregar mesa
                messagebox.showinfo("Éxito", "Mesa agregada exitosamente.")  # Mostrar mensaje de éxito
            except Exception as e:
                messagebox.showerror("Error", f"Error al agregar la mesa: {e}")  # Mensaje de error si ocurre
        else:
            messagebox.showerror("Error", "Todos los campos son obligatorios.")  # Mensaje si hay campos vacíos


if __name__ == "__main__":
    Usuario()
